package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Customer;
import com.example.demo.repo.CustomerRepo;


@Service
public class CustomerService {
	
	@Autowired
	CustomerRepo repo;

	public void store(Customer cust) {
		repo.save(cust);
		
	}

	public List<Customer> getCustomer() {
		List<Customer> list=repo.findAll();

		return list;
	}
	public Customer fetchstdbyemailandpass(String email, String password) {
        // TODO Auto-generated method stub
        return repo.findByEmailAndPassword(email, password);
    }

}
